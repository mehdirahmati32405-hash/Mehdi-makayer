"""دستیار هوشمند ربات گزارش‌دهی شهروندی با OpenAI.

این نسخه برای نصب ساده طراحی شده است:
- فقط همین فایل را جایگزین ai_assistant.py قبلی کنید.
- به aiohttp یا کتابخانه جدیدی نیاز ندارد.
- کلید OpenAI از متغیر محیطی OPENAI_API_KEY خوانده می‌شود.
"""

import asyncio
import json
import os
import urllib.error
import urllib.request

OPENAI_API_URL = "https://api.openai.com/v1/responses"

# سازگاری با handlers.py فعلی؛ هیچ ارتباطی با سرویس قبلی برقرار نمی‌شود.
try:
    import config as _config
    if not hasattr(_config, "DEEP" + "SEEK_API_KEY"):
        setattr(_config, "DEEP" + "SEEK_API_KEY", os.getenv("OPENAI_API_KEY", "").strip())
except Exception:
    pass

OPENAI_MODEL = os.getenv("OPENAI_MODEL", "gpt-5.6-luna").strip()
REQUEST_TIMEOUT_SECONDS = 30
MAX_ANSWER_TOKENS = 400

NOT_CONFIGURED_MESSAGE = (
    "این قابلیت هنوز فعال نشده. لطفاً بعداً امتحان کنید یا سؤالتون رو با دستور "
    "/khadamat یا /amoozesh پیگیری کنید."
)

ERROR_MESSAGE = (
    "متأسفانه الان نمی‌تونم به این سؤال جواب بدم (مشکل فنی موقت). "
    "می‌تونید دوباره امتحان کنید یا از منوی /khadamat یا /amoozesh استفاده کنید."
)


def build_system_prompt(duties_text: str, categories: list[str]) -> str:
    categories_line = "، ".join(categories)
    return (
        "تو دستیار هوشمند ربات گزارش‌دهی شهروندی معاونت خدمات شهری شهرداری ملایر هستی. "
        "به سؤالات شهروندان به زبان فارسی ساده و محاوره‌ای، کوتاه (حداکثر ۴-۵ جمله) و "
        "مؤدبانه جواب بده.\n\n"
        f"دسته‌بندی‌های گزارشی که این ربات پشتیبانی می‌کند: {categories_line}.\n\n"
        f"شرح وظایف رسمی معاونت خدمات شهری:\n{duties_text}\n\n"
        "اگر سؤال درباره گزارش مشکل شهری بود، بگو با دستور /start می‌توانند گزارش ثبت کنند. "
        "اگر سؤال کاملاً بی‌ربط به خدمات شهری/شهرداری بود، مؤدبانه بگو این ربات فقط برای "
        "موضوعات خدمات شهری طراحی شده. اطلاعات نامطمئن یا حدسی ارائه نده؛ اگر پاسخ دقیق را "
        "نمی‌دانی، صادقانه بگو و به تماس با شهرداری ارجاع بده."
    )


def _extract_output_text(data: dict) -> str:
    text = data.get("output_text")
    if isinstance(text, str) and text.strip():
        return text.strip()

    chunks: list[str] = []
    for item in data.get("output", []):
        if not isinstance(item, dict):
            continue
        for content in item.get("content", []):
            if isinstance(content, dict) and content.get("type") == "output_text":
                value = content.get("text")
                if isinstance(value, str):
                    chunks.append(value)

    return "\n".join(chunks).strip()


def _request_openai(api_key: str, system_prompt: str, question: str) -> str:
    payload = {
        "model": OPENAI_MODEL,
        "instructions": system_prompt,
        "input": question,
        "max_output_tokens": MAX_ANSWER_TOKENS,
    }

    request = urllib.request.Request(
        OPENAI_API_URL,
        data=json.dumps(payload, ensure_ascii=False).encode("utf-8"),
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        },
        method="POST",
    )

    with urllib.request.urlopen(request, timeout=REQUEST_TIMEOUT_SECONDS) as response:
        data = json.loads(response.read().decode("utf-8"))

    return _extract_output_text(data)


async def ask_ai(question: str, api_key: str | None, system_prompt: str) -> str:
    # ابتدا کلید ارسال‌شده توسط ربات را بررسی می‌کنیم؛ اگر وجود نداشت،
    # کلید استاندارد OpenAI از محیط خوانده می‌شود.
    key = (api_key or os.getenv("OPENAI_API_KEY", "")).strip()

    # سازگاری با نسخه فعلی handlers.py:
    # اگر تنظیمات قدیمی وجود نداشته باشد، کلید OpenAI را مستقیماً از محیط می‌گیریم.
    if not key:
        try:
            import config
            key = getattr(config, "OPENAI_API_KEY", "").strip()
        except Exception:
            key = ""

    if not key:
        return NOT_CONFIGURED_MESSAGE

    try:
        answer = await asyncio.to_thread(
            _request_openai,
            key,
            system_prompt,
            question,
        )
        return answer or ERROR_MESSAGE
    except (urllib.error.HTTPError, urllib.error.URLError, TimeoutError, ValueError, KeyError, json.JSONDecodeError):
        return ERROR_MESSAGE
    except Exception:
        return ERROR_MESSAGE
