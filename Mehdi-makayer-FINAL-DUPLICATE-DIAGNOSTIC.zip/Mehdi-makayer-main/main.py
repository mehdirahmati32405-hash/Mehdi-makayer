import asyncio
import logging
from datetime import datetime, timezone

from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.types import BotCommand, BotCommandScopeChat, BotCommandScopeDefault

import config
import db
from report_dedup import ConfirmationDedupMiddleware
from handlers import router
from location_handlers_smart import location_router
from location_admin import location_admin_router
from location_db_upgrade import init_location_db
from seasonal_content import SEASON_BY_MONTH, SEASON_TEXTS


REMINDER_CHECK_INTERVAL_SECONDS = 60 * 60
REMINDER_STALE_HOURS = 48
WEEKLY_SUMMARY_CHECK_INTERVAL_SECONDS = 60 * 60
WEEKLY_SUMMARY_WEEKDAY = 6
WEEKLY_SUMMARY_HOUR_UTC = 5
SEASONAL_CHECK_INTERVAL_SECONDS = 60 * 60 * 6


async def set_commands(bot: Bot) -> None:
    base_commands = [
        BotCommand(command="start", description="شروع / ثبت گزارش جدید"),
        BotCommand(command="myreports", description="گزارش‌های من"),
        BotCommand(command="khadamat", description="خدمات و اطلاعات شهرداری"),
        BotCommand(command="amoozesh", description="آموزش شهروندی"),
        BotCommand(command="quiz", description="آزمون شهروند نمونه"),
        BotCommand(command="quiz_top", description="جدول امتیازات آزمون"),
        BotCommand(command="pishnahad", description="ارسال پیشنهاد به شهرداری"),
        BotCommand(command="tashakor", description="تشکر از عوامل خدمات شهری"),
        BotCommand(command="subscribe", description="عضویت در اطلاعیه‌های مهم"),
        BotCommand(command="unsubscribe", description="لغو اشتراک اطلاعیه‌ها"),
        BotCommand(command="ask", description="پرسش هوشمند از ربات"),
        BotCommand(command="stats", description="آمار کلی گزارش‌ها"),
        BotCommand(command="location_report", description="ثبت گزارش موش و سگ با موقعیت مکانی"),
        BotCommand(command="cancel", description="لغو عملیات جاری"),
    ]

    await bot.set_my_commands(base_commands, scope=BotCommandScopeDefault())

    admin_commands = base_commands + [
        BotCommand(command="search", description="جست‌وجوی گزارش‌ها"),
        BotCommand(command="export", description="خروجی اکسل همه گزارش‌ها"),
        BotCommand(command="hotspots", description="نقاط داغ گزارش‌های باز"),
        BotCommand(command="broadcast", description="ارسال اطلاعیه به مشترکین"),
        BotCommand(command="location_admin", description="پنل مدیریت مکانی"),
        BotCommand(command="lstats", description="آمار گزارش‌های مکانی"),
        BotCommand(command="lhotspots", description="نقاط داغ مکانی"),
    ]

    try:
        await bot.set_my_commands(
            admin_commands,
            scope=BotCommandScopeChat(chat_id=config.ADMIN_GROUP_ID),
        )
    except Exception:
        logging.warning("تنظیم دستورات ویژه گروه ادمین ممکن نشد.")


async def reminder_loop(bot: Bot) -> None:
    while True:
        try:
            stale_reports = db.get_stale_reports(hours=REMINDER_STALE_HOURS)

            for report in stale_reports:
                if not report["admin_chat_id"] or not report["admin_message_id"]:
                    continue

                try:
                    await bot.send_message(
                        chat_id=report["admin_chat_id"],
                        text=(
                            f"⏰ یادآوری: گزارش {db.report_code(report['id'])} بیش از "
                            f"{REMINDER_STALE_HOURS} ساعت است در وضعیت "
                            f"«{report['status']}» باقی مانده. لطفاً بررسی شود."
                        ),
                        reply_to_message_id=report["admin_message_id"],
                    )
                    db.mark_reminded(report["id"])
                except Exception:
                    logging.exception(
                        "ارسال یادآوری برای گزارش %s ناموفق بود.",
                        report["id"],
                    )

        except Exception:
            logging.exception("خطا در بررسی گزارش‌های راکد.")

        await asyncio.sleep(REMINDER_CHECK_INTERVAL_SECONDS)


async def weekly_summary_loop(bot: Bot) -> None:
    while True:
        try:
            now = datetime.now(timezone.utc)
            already_sent_key = db.get_state("last_weekly_summary_date")
            today_str = now.strftime("%Y-%m-%d")

            if (
                now.weekday() == WEEKLY_SUMMARY_WEEKDAY
                and now.hour == WEEKLY_SUMMARY_HOUR_UTC
                and already_sent_key != today_str
            ):
                stats = db.get_period_stats(days=7)
                top_reporters = db.get_top_reporters(days=30, limit=5)

                lines = [
                    "📊 گزارش هفتگی خودکار — عملکرد ربات گزارش شهروندی\n",
                    f"گزارش‌های ثبت‌شده در ۷ روز اخیر: {stats['total']}",
                    f"رسیدگی‌شده از همین بازه: {stats['done']}",
                ]

                if stats["top_category"]:
                    lines.append(
                        f"پرتکرارترین دسته: {stats['top_category']} "
                        f"({stats['top_category_count']} مورد)"
                    )

                if top_reporters:
                    lines.append("\n🌟 فعال‌ترین شهروندان (۳۰ روز اخیر):")
                    for i, reporter in enumerate(top_reporters, start=1):
                        lines.append(
                            f"{i}. {reporter['user_name']} — "
                            f"{reporter['c']} گزارش"
                        )

                try:
                    await bot.send_message(
                        chat_id=config.ADMIN_GROUP_ID,
                        text="\n".join(lines),
                    )
                    db.set_state("last_weekly_summary_date", today_str)
                except Exception:
                    logging.exception("ارسال گزارش هفتگی ناموفق بود.")

        except Exception:
            logging.exception("خطا در بررسی زمان‌بندی گزارش هفتگی.")

        await asyncio.sleep(WEEKLY_SUMMARY_CHECK_INTERVAL_SECONDS)


async def seasonal_reminder_loop(bot: Bot) -> None:
    while True:
        try:
            now = datetime.now(timezone.utc)
            current_season = SEASON_BY_MONTH[now.month]
            season_key = f"{current_season}-{now.year}"
            last_sent = db.get_state("last_season_reminder")

            if last_sent != season_key:
                text = SEASON_TEXTS[current_season]

                try:
                    await bot.send_message(
                        chat_id=config.ADMIN_GROUP_ID,
                        text=text,
                    )
                    db.set_state("last_season_reminder", season_key)
                except Exception:
                    logging.exception("ارسال پیام فصلی ناموفق بود.")

        except Exception:
            logging.exception("خطا در بررسی زمان‌بندی پیام فصلی.")

        await asyncio.sleep(SEASONAL_CHECK_INTERVAL_SECONDS)


async def main() -> None:
    logging.basicConfig(level=logging.INFO)

    db.init_db()
    logging.info("DATABASE IDEMPOTENCY: READY | DB_PATH=%s", db.DB_PATH)
    init_location_db()

    bot = Bot(
        token=config.BOT_TOKEN,
        default=DefaultBotProperties(parse_mode=ParseMode.HTML),
    )

    await set_commands(bot)

    dispatcher = Dispatcher(storage=MemoryStorage())

    # ضد ثبت تکراری گزارش:
    # اگر دکمه «ارسال گزارش» سریع چند بار لمس شود، فقط اولین callback
    # وارد submit_report() می‌شود.
    dispatcher.callback_query.outer_middleware(
        ConfirmationDedupMiddleware(ttl_seconds=180)
    )

    dispatcher.include_router(router)
    dispatcher.include_router(location_router)
    dispatcher.include_router(location_admin_router)

    asyncio.create_task(reminder_loop(bot))
    asyncio.create_task(weekly_summary_loop(bot))
    asyncio.create_task(seasonal_reminder_loop(bot))

    logging.info("ربات در حال اجراست...")
    await dispatcher.start_polling(bot)


if __name__ == "__main__":
    asyncio.run(main())
